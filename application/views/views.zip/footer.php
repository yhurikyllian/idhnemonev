<div class="pull-right">
	Indohun by <a href="https://whalecoding.com">Whale Studio</a>
</div>
<div class="clearfix"></div>