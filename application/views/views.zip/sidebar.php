<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
  <div class="menu_section">
    <h3>General</h3>
    <ul class="nav side-menu">
      <li><a href="<?php echo base_url()."index.php/addproject"?>"><i class="fa fa-home"></i>ADD NEW PROJECT</a></li>
      <li><a href="<?php echo base_url()."index.php/project_report"?>"><i class="fa fa-list-alt"></i>PROJECT REPORT</a></li>
      <li><a href="<?php echo base_url()."index.php/addevent"?>"><i class="fa fa-star"></i>ADD NEW EVENT</a></li>
      <li><a href="<?php echo base_url()."index.php/addspeaker"?>"><i class="fa fa-bullhorn"></i>ADD NEW SPEAKER</a></li>
      <li><a href="<?php echo base_url()."index.php/index"?>"><i class="fa fa-briefcase"></i>EVENT REPORT</a></li>
      <li><a href="<?php echo base_url()."index.php/addattendees"?>"><i class="fa fa-plus-square"></i>ADD ATTENDEES</a></li>
      <li><a href="<?php echo base_url()."index.php/peserta"?>"><i class="fa fa-users"></i>ATTENDEES REPORT</a></li>
      <li><a href="<?php echo base_url()."index.php/survey"?>"><i class="fa fa-sort-amount-desc"></i>SURVEY REPORT</a></li>
      <li><a href="<?php echo base_url()."index.php/edit"?>"><i class="fa fa-edit"></i>EDIT DATA</a></li>
      <!-- <li><a href="<?php echo base_url()."index.php/adduser"?>"><i class="fa fa-plus-circle"></i>ADD USERS</a></li> -->
      <li><a href="<?php echo base_url()."index.php/chart"?>"><i class="fa fa-bar-chart"></i>CHART</a></li>
      <li><a href="<?php echo base_url()."index.php/geomaps"?>"><i class="fa fa-map-marker"></i>GEOMAPS</a></li>
    <ul class="nav child_menu">
          
        </ul>
      </li>

    </ul>
  </div>

  <div class="menu_section"></div>

</div>            