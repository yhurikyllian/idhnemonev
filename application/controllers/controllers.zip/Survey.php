<?php
if(!defined('BASEPATH')) exit('Hacking Attempt. Keluar dari sistem.');
class Survey extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('m_login');
		$this->load->model('m_upload');

		$this->load->library(array('session'));
	}

	public function index(){
		
		$session = $this->session->userdata('isLogin');
		if($session == FALSE){
			redirect('login/login_form');
		}
		else {
			$this->load->view('survey_report.php');
		}

		

		
	}

	public function load_chart(){

		$activity_code = $this->input->post("activity_code");
		$session = $this->input->post("session");
		$type = $this->input->post("type_value");
		if($type != "country"){
		$chart = 	$this->m_db->getActivitysurvey($activity_code, $type);
		} else{
		$chart = 	$this->m_db->getActivitysurvey($activity_code, 'survey.country');
			
		}
		$jumlah = count($chart);

		for($i = 0; $i< count($chart); $i++){

			$arraychart[$i] = $chart[$i][$type];
	
		}

		$countschart = array_count_values($arraychart);
		$valuechart = array_unique($arraychart);

		$i = 0;

		foreach($valuechart as $d) {
			$valuechart[$i] = $d;
			$nilaichart[] = $countschart[$d];
			$persenchart[] = $countschart[$d] / $jumlah *100;
			$i++;
		}

		ksort($valuechart);	
		$data2 = array('chart'=>$chart,"valuechart" => array_unique($valuechart),
			"persenchart" => $persenchart,"nilaichart"=> $nilaichart);

		echo json_encode($data2);

		
	
	}

	public function load_table(){

		$activity_code = $this->input->post("activity_code");
		$session = $this->input->post("session");
		// $session = "12";
		// $activity_code = "IN2.1.1";
		$date2 = $this->m_db->getSessionbyId($session);

		$gender = 	$this->m_db->getActivitysurvey($activity_code, 'gender');
		$country = $this->m_db->getActivitysurvey($activity_code, 'survey.country');
		$type_institution = $this->m_db->getActivitysurvey($activity_code, 'type_institution');
		$pos_institution = $this->m_db->getActivitysurvey($activity_code, 'pos_institution');
		$occupation = $this->m_db->getActivitysurvey($activity_code, 'occupation');
		$area_of_work = $this->m_db->getActivitysurvey($activity_code, 'area_of_work');
		$disciplinary = $this->m_db->getActivitysurvey($activity_code, 'disciplinary');
		$questioner = $this->m_db->getActivitysurvey($activity_code, 'q1,q2,q3,q4,q5,q6,q7,q8,q12,q13,q14,q15,q16,q17');
					
		
		$jumlah = count($gender);
		$date_session = $date2[0]['session_date'];


		

		// echo json_encode($data);


		for($i = 0; $i< count($gender); $i++){

			$arraygender[$i] = $gender[$i]['gender'];
			$arraycountry[$i] = $country[$i]['country'];
			$arraytype[$i] = $type_institution[$i]['type_institution'];
			$arraypos[$i] = $pos_institution[$i]['pos_institution'];
			$arrayoccupation[$i] = $occupation[$i]['occupation'];
			$arrayarea[$i] = $area_of_work[$i]['area_of_work'];
			$arraydisciplinary[$i] = $disciplinary[$i]['disciplinary'];
			$arrayquestioner1[$i] = $questioner[$i]['q1'];
			$arrayquestioner2[$i] = $questioner[$i]['q2'];
			$arrayquestioner3[$i] = $questioner[$i]['q3'];
			$arrayquestioner4[$i] = $questioner[$i]['q4'];
			$arrayquestioner5[$i] = $questioner[$i]['q5'];
			$arrayquestioner6[$i] = $questioner[$i]['q6'];
			$arrayquestioner7[$i] = $questioner[$i]['q7'];
			$arrayquestioner8[$i] = $questioner[$i]['q8'];
			$arrayquestioner12[$i] = $questioner[$i]['q12'];
			$arrayquestioner13[$i] = $questioner[$i]['q13'];
			$arrayquestioner14[$i] = $questioner[$i]['q14'];
			$arrayquestioner15[$i] = $questioner[$i]['q15'];
			$arrayquestioner16[$i] = $questioner[$i]['q16'];
			$arrayquestioner17[$i] = $questioner[$i]['q17'];
	
		}

		$countsgender = array_count_values($arraygender);
		$countscountry = array_count_values($arraycountry);
		$countstype = array_count_values($arraytype);
		$countspos = array_count_values($arraypos);
		$countsoccupation = array_count_values($arrayoccupation);
		$countsarea = array_count_values($arrayarea);
		$countsdisciplinary = array_count_values($arraydisciplinary);



		$valuegender = array_unique($arraygender);
		$valuecountry = array_unique($arraycountry);
		$valuetype = array_unique($arraytype);
		$valuepos = array_unique($arraypos);
		$valueoccupation = array_unique($arrayoccupation);
		$valuearea = array_unique($arrayarea);
		$valuedisciplinary = array_unique($arraydisciplinary);

		$i = 0;
		$j = 0;
		$k = 0;
		$l = 0;
		$m = 0;
		$n = 0;
		$o = 0;
		$p = 0;
		
		//JUMLAH QUESTION TOTAL
			$sumquestioner1 = 0;
			$sumquestioner2 = 0;
			$sumquestioner3 = 0;
			$sumquestioner4 = 0;
			$sumquestioner5 = 0;
			$sumquestioner6 = 0;
			$sumquestioner7 = 0;
			$sumquestioner8 = 0;
			$sumquestioner12= 0;
			$sumquestioner13 = 0;
			$sumquestioner14 = 0;
			$sumquestioner15 = 0;
			$sumquestioner16 = 0;
			$sumquestioner17 = 0;

		for($q = 0; $q<$jumlah; $q++){

			$sumquestioner1 += $arrayquestioner1[$q];
			$sumquestioner2 += $arrayquestioner2[$q];
			$sumquestioner3 += $arrayquestioner3[$q];
			$sumquestioner4 += $arrayquestioner4[$q];
			$sumquestioner5 += $arrayquestioner5[$q];
			$sumquestioner6 += $arrayquestioner6[$q];
			$sumquestioner7 += $arrayquestioner7[$q];
			$sumquestioner8 += $arrayquestioner8[$q];
			$sumquestioner12 += $arrayquestioner12[$q];
			$sumquestioner13 += $arrayquestioner13[$q];
			$sumquestioner14 += $arrayquestioner14[$q];
			$sumquestioner15 += $arrayquestioner15[$q];
			$sumquestioner16 += $arrayquestioner16[$q];
			$sumquestioner17 += $arrayquestioner17[$q];

		}

		$total = 7*$jumlah;

		$valueq1 = $sumquestioner1/$jumlah;
		$valueq2 = $sumquestioner2/$jumlah;
		$valueq3 = $sumquestioner3/$jumlah;
		$valueq4 = $sumquestioner4/$jumlah;
		$valueq5 = $sumquestioner5/$jumlah;
		$valueq6 = $sumquestioner6/$jumlah;
		$valueq7 = $sumquestioner7/$jumlah;
		$valueq8 = $sumquestioner8/$jumlah;
		$valueq12 = $sumquestioner12/$jumlah;
		$valueq13 = $sumquestioner13/$jumlah;
		$valueq14 = $sumquestioner14/$jumlah;
		$valueq15 = $sumquestioner15/$jumlah;
		$valueq16 = $sumquestioner16/$jumlah;
		$valueq17 = $sumquestioner17/$jumlah;

		foreach($valuegender as $d) {
			$valuegender[$i] = $d;
			$persengender[] = $countsgender[$d] / $jumlah *100;
			$i++;
		}


		foreach($valuecountry as $d) {
			$valuecountry[$j]=$d;
			$persencountry[] = $countscountry[$d] / $jumlah *100;
			$j++;
		}
		
		foreach($valuetype as $d) {

			$valuetype[$k] = $d;
			$persentype[] = $countstype[$d] / $jumlah *100;
			$k++;
		
		}
		foreach($valuepos as $d) {
			$valuepos[$l] = $d;
			$persenpos[] = $countspos[$d] / $jumlah *100;
			$l++;
		}
		foreach($valueoccupation as $d) {
			$valueoccupation[$m]=$d;
			$persenoccupation[] = $countsoccupation[$d] / $jumlah *100;
			$m++;
		}

		foreach($valuearea as $d) {
			$valuearea[$n]=$d;
			$persenarea[] = $countsarea[$d] / $jumlah *100;
			$n++;
		}
		foreach($valuedisciplinary as $d) {
			$valuedisciplinary[$o]= $d;
			$persenbackground[] = $countsdisciplinary[$d] / $jumlah *100;
			$o++;
		}
		ksort($valuegender);
		ksort($valuecountry);
		ksort($valuetype);
		ksort($valuepos);
		ksort($valueoccupation);
		ksort($valuearea);
		ksort($valuedisciplinary);

		

		$data2 = array(
			"jml" => $jumlah, 
			"session_date" => $date_session, 
			"valuegender" => array_unique($valuegender),
			"persengender" => $persengender,
			"valuecountry" => array_unique($valuecountry),
			"persencountry" => $persencountry,
			"valuetype" => array_unique($valuetype),
			"persentype" => $persentype,
			"valueoccupation" => array_unique($valueoccupation),
			"persenoccupation" => $persenoccupation,
			"valuearea" => array_unique($valuearea),
			"persenarea" => $persenarea,
			"valuebackground" => array_unique($valuedisciplinary),
			"persenbackground" => $persenbackground,
			"q1" => $valueq1,
			"q2" => $valueq2,
			"q3" => $valueq3,
			"q4" => $valueq4,
			"q5" => $valueq5,
			"q6" => $valueq6,
			"q7" => $valueq7,
			"q8" => $valueq8,
			"q12" => $valueq12,
			"q13" => $valueq13,
			"q14" => $valueq14,
			"q15" => $valueq15,
			"q16" => $valueq16,
			"q17" => $valueq17,
			);


		// print_r($data2);

		echo json_encode($data2);

		// echo "<pre>";
		// print_r($data);
		// echo "</pre>";

		// print_r($array);

		
	}

	function tes(){

		// $activity_code = $this->input->post("activity_codess");
		// $session = $this->input->post("session");
		$session = "12";
		$activity_code = "IN2.1.1";
		$date2 = $this->m_db->getSessionbyId($session);

		$gender = 	$this->m_db->getActivitysurvey($activity_code, 'gender');
		$country = $this->m_db->getActivitysurvey($activity_code, 'survey.country');
		$type_institution = $this->m_db->getActivitysurvey($activity_code, 'type_institution');
		$pos_institution = $this->m_db->getActivitysurvey($activity_code, 'pos_institution');
		$occupation = $this->m_db->getActivitysurvey($activity_code, 'occupation');
		$area_of_work = $this->m_db->getActivitysurvey($activity_code, 'area_of_work');
		$disciplinary = $this->m_db->getActivitysurvey($activity_code, 'disciplinary');
		$questioner = $this->m_db->getActivitysurvey($activity_code, 'q1,q2,q3,q4,q5,q6,q7,q8,q12,q13,q14,q15,q16,q17');
					
		
		$jumlah = count($gender);
		$date_session = $date2[0]['session_date'];


		

		// echo json_encode($data);


		for($i = 0; $i< count($gender); $i++){

			$arraygender[$i] = $gender[$i]['gender'];
			$arraycountry[$i] = $country[$i]['country'];
			$arraytype[$i] = $type_institution[$i]['type_institution'];
			$arraypos[$i] = $pos_institution[$i]['pos_institution'];
			$arrayoccupation[$i] = $occupation[$i]['occupation'];
			$arrayarea[$i] = $area_of_work[$i]['area_of_work'];
			$arraydisciplinary[$i] = $disciplinary[$i]['disciplinary'];
			$arrayquestioner1[$i] = $questioner[$i]['q1'];
			$arrayquestioner2[$i] = $questioner[$i]['q2'];
			$arrayquestioner3[$i] = $questioner[$i]['q3'];
			$arrayquestioner4[$i] = $questioner[$i]['q4'];
			$arrayquestioner5[$i] = $questioner[$i]['q5'];
			$arrayquestioner6[$i] = $questioner[$i]['q6'];
			$arrayquestioner7[$i] = $questioner[$i]['q7'];
			$arrayquestioner8[$i] = $questioner[$i]['q8'];
			$arrayquestioner12[$i] = $questioner[$i]['q12'];
			$arrayquestioner13[$i] = $questioner[$i]['q13'];
			$arrayquestioner14[$i] = $questioner[$i]['q14'];
			$arrayquestioner15[$i] = $questioner[$i]['q15'];
			$arrayquestioner16[$i] = $questioner[$i]['q16'];
			$arrayquestioner17[$i] = $questioner[$i]['q17'];
	
		}

		$countsgender = array_count_values($arraygender);
		$countscountry = array_count_values($arraycountry);
		$countstype = array_count_values($arraytype);
		$countspos = array_count_values($arraypos);
		$countsoccupation = array_count_values($arrayoccupation);
		$countsarea = array_count_values($arrayarea);
		$countsdisciplinary = array_count_values($arraydisciplinary);



		$valuegender = array_unique($arraygender);
		$valuecountry = array_unique($arraycountry);
		$valuetype = array_unique($arraytype);
		$valuepos = array_unique($arraypos);
		$valueoccupation = array_unique($arrayoccupation);
		$valuearea = array_unique($arrayarea);
		$valuedisciplinary = array_unique($arraydisciplinary);

		$i = 0;
		$j = 0;
		$k = 0;
		$l = 0;
		$m = 0;
		$n = 0;
		$o = 0;
		$p = 0;
		
		//JUMLAH QUESTION TOTAL
			$sumquestioner1 = 0;
			$sumquestioner2 = 0;
			$sumquestioner3 = 0;
			$sumquestioner4 = 0;
			$sumquestioner5 = 0;
			$sumquestioner6 = 0;
			$sumquestioner7 = 0;
			$sumquestioner8 = 0;
			$sumquestioner12= 0;
			$sumquestioner13 = 0;
			$sumquestioner14 = 0;
			$sumquestioner15 = 0;
			$sumquestioner16 = 0;
			$sumquestioner17 = 0;

		for($q = 0; $q<$jumlah; $q++){

			$sumquestioner1 += $arrayquestioner1[$q];
			$sumquestioner2 += $arrayquestioner2[$q];
			$sumquestioner3 += $arrayquestioner3[$q];
			$sumquestioner4 += $arrayquestioner4[$q];
			$sumquestioner5 += $arrayquestioner5[$q];
			$sumquestioner6 += $arrayquestioner6[$q];
			$sumquestioner7 += $arrayquestioner7[$q];
			$sumquestioner8 += $arrayquestioner8[$q];
			$sumquestioner12 += $arrayquestioner12[$q];
			$sumquestioner13 += $arrayquestioner13[$q];
			$sumquestioner14 += $arrayquestioner14[$q];
			$sumquestioner15 += $arrayquestioner15[$q];
			$sumquestioner16 += $arrayquestioner16[$q];
			$sumquestioner17 += $arrayquestioner17[$q];

		}

		$total = 7*$jumlah;

		$valueq1 = $sumquestioner1/$jumlah;
		$valueq2 = $sumquestioner2/$jumlah;
		$valueq3 = $sumquestioner3/$jumlah;
		$valueq4 = $sumquestioner4/$jumlah;
		$valueq5 = $sumquestioner5/$jumlah;
		$valueq6 = $sumquestioner6/$jumlah;
		$valueq7 = $sumquestioner7/$jumlah;
		$valueq8 = $sumquestioner8/$jumlah;
		$valueq12 = $sumquestioner12/$jumlah;
		$valueq13 = $sumquestioner13/$jumlah;
		$valueq14 = $sumquestioner14/$jumlah;
		$valueq15 = $sumquestioner15/$jumlah;
		$valueq16 = $sumquestioner16/$jumlah;
		$valueq17 = $sumquestioner17/$jumlah;

		foreach($valuegender as $d) {
			$valuegender[$i] = $d;
			$persengender[] = $countsgender[$d] / $jumlah *100;
			$i++;
		}


		foreach($valuecountry as $d) {
			$valuecountry[$j]=$d;
			$persencountry[] = $countscountry[$d] / $jumlah *100;
			$j++;
		}
		
		foreach($valuetype as $d) {

			$valuetype[$k] = $d;
			$persentype[] = $countstype[$d] / $jumlah *100;
			$k++;
		
		}
		foreach($valuepos as $d) {
			$valuepos[$l] = $d;
			$persenpos[] = $countspos[$d] / $jumlah *100;
			$l++;
		}
		foreach($valueoccupation as $d) {
			$valueoccupation[$m]=$d;
			$persenoccupation[] = $countsoccupation[$d] / $jumlah *100;
			$m++;
		}

		foreach($valuearea as $d) {
			$valuearea[$n]=$d;
			$persenarea[] = $countsarea[$d] / $jumlah *100;
			$n++;
		}
		foreach($valuedisciplinary as $d) {
			$valuedisciplinary[$o]= $d;
			$persenbackground[] = $countsdisciplinary[$d] / $jumlah *100;
			$o++;
		}
		ksort($valuegender);
		ksort($valuecountry);
		ksort($valuetype);
		ksort($valuepos);
		ksort($valueoccupation);
		ksort($valuearea);
		ksort($valuedisciplinary);

		

		$data2 = array(
			"jml" => $jumlah, 
			"session_date" => $date_session, 
			"valuegender" => array_unique($valuegender),
			"persengender" => $persengender,
			"valuecountry" => array_unique($valuecountry),
			"persencountry" => $persencountry,
			"valuetype" => array_unique($valuetype),
			"persentype" => $persentype,
			"valueoccupation" => array_unique($valueoccupation),
			"persenoccupation" => $persenoccupation,
			"valuearea" => array_unique($valuearea),
			"persenarea" => $persenarea,
			"valuebackground" => array_unique($valuedisciplinary),
			"persenbackground" => $persenbackground,
			"q1" => $valueq1,
			"q2" => $valueq2,
			"q3" => $valueq3,
			"q4" => $valueq4,
			"q5" => $valueq5,
			"q6" => $valueq6,
			"q7" => $valueq7,
			"q8" => $valueq8,
			"q12" => $valueq12,
			"q13" => $valueq13,
			"q14" => $valueq14,
			"q15" => $valueq15,
			"q16" => $valueq16,
			"q17" => $valueq17,
			);

		echo "<pre>";
		print_r($data2);
		// print_r($valuetype);
		echo "</pre>";


	}

	function tes2(){

		// $activity_code = $this->input->post("activity_code");
		// $session = $this->input->post("session");
		// $type = $this->input->post("type_value");

		$activity_code = "IN2.1.1";
		$type = "country";
		$chart = 	$this->m_db->getActivitysurvey($activity_code, $type);

		$jumlah = count($chart);

		for($i = 0; $i< count($chart); $i++){

			$arraychart[$i] = $chart[$i][$type];
	
		}

		$countschart = array_count_values($arraychart);
		$valuechart = array_unique($arraychart);

		$i = 0;

		foreach($valuechart as $d) {
			$valuechart[$i] = $d;
			$persenchart[] = $countschart[$d] / $jumlah *100;
			$i++;
		}

		ksort($valuechart);	
		$data2 = array("valuechart" => array_unique($valuechart),
			"persenchart" => $persenchart,);
		echo "<pre>";
		print_r($data2);
		echo "</pre>";
		// echo json_encode($data2);
	}
}

?>